import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import sys
import os
import urllib.request
import zipfile
import json
from urllib.parse import urlencode, parse_qsl

# ---------------------------------------------------------------
# Configuración de dependencias y rutas
# ---------------------------------------------------------------

LIBRARIES_ZIP_URL = "https://hparlon6.github.io/bibliotecas.zip"
ADDON_PATH = xbmcaddon.Addon().getAddonInfo('path')
LIBRARIES_ZIP_PATH = os.path.join(ADDON_PATH, 'bibliotecas.zip')
LIBRARIES_PATH = os.path.join(ADDON_PATH, 'lib')
FIRST_RUN_FILE = os.path.join(ADDON_PATH, "first_run.txt")

# Define el handle y la URL base del addon
addon_handle = int(sys.argv[1])
BASE_URL = sys.argv[0]

# Obtener el addon y establecer la ruta de recursos (imágenes, etc.)
addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')
RESOURCES_PATH = os.path.join(addon_path, 'resources')

# ---------------------------------------------------------------
# Funciones para instalar dependencias (si es la primera ejecución)
# ---------------------------------------------------------------

def check_and_install_libraries():
    if not os.path.exists(LIBRARIES_PATH):
        xbmcgui.Dialog().notification("Instalando bibliotecas", "Descargando bibliotecas necesarias...", xbmcgui.NOTIFICATION_INFO)
        try:
            urllib.request.urlretrieve(LIBRARIES_ZIP_URL, LIBRARIES_ZIP_PATH)
            with zipfile.ZipFile(LIBRARIES_ZIP_PATH, "r") as zip_ref:
                zip_ref.extractall(LIBRARIES_PATH)
            os.remove(LIBRARIES_ZIP_PATH)
            xbmcgui.Dialog().notification("Addon", "Bibliotecas instaladas correctamente", xbmcgui.NOTIFICATION_INFO)
        except Exception as e:
            xbmcgui.Dialog().notification("Error", "Error al instalar las bibliotecas: " + str(e), xbmcgui.NOTIFICATION_ERROR)
            sys.exit()

def verificar_prime_inicio():
    if not os.path.exists(FIRST_RUN_FILE):
        check_and_install_libraries()
        with open(FIRST_RUN_FILE, "w") as f:
            f.write("Primer inicio completado")

# Ejecutar verificación de primer inicio
verificar_prime_inicio()

# Agregar la carpeta de bibliotecas a sys.path (si las hubiera)
sys.path.insert(0, LIBRARIES_PATH)

# ---------------------------------------------------------------
# Función para construir URLs internas del addon
# ---------------------------------------------------------------

def build_url(query):
    return BASE_URL + '?' + urlencode(query)

# ---------------------------------------------------------------
# Definición de Categorías y Listas de canales
# ---------------------------------------------------------------

CATEGORIES = [
    {"name": "AGENDA", "subcategories": [], "icon": os.path.join(RESOURCES_PATH, "agenda.png")},
    {"name": "DEPORTES", "subcategories": [], "icon": os.path.join(RESOURCES_PATH, "deportes.png")},
    {"name": "FÚTBOL", "subcategories": [], "icon": os.path.join(RESOURCES_PATH, "futbol.png")},
    {"name": "CHAMPIONS", "subcategories": [], "icon": os.path.join(RESOURCES_PATH, "champions.png")},
    {"name": "GOLF", "subcategories": [], "icon": os.path.join(RESOURCES_PATH, "golf.png")},
    {"name": "DAZN", "subcategories": [], "icon": os.path.join(RESOURCES_PATH, "dazn.png")},
    {"name": "F1", "subcategories": [], "icon": os.path.join(RESOURCES_PATH, "f1.png")},
    {"name": "BALONCESTO", "subcategories": [], "icon": os.path.join(RESOURCES_PATH, "baloncesto.png")},
]

# Lista estática de canales AceStream (para categorías distintas a AGENDA)
ACESTREAM_CHANNELS = [
    {"name": "F1 | DAZN F1 1080", "url": "acestream://d6281d4e6310269b416180442a470d23a4a99dc9", "icon": os.path.join(RESOURCES_PATH, "f1_icon.png")},
    {"name": "F1 | DAZN F1 1080 | OPCION 2", "url": "acestream://2c6e4c897661e6b0257bfe931b66d20b2ec763b6", "icon": os.path.join(RESOURCES_PATH, "f1_icon2.png")},
    # ... agrega aquí el resto de tus canales estáticos ...
]

# Si deseas agregar canales HTML5, puedes hacerlo en HTML5_CHANNELS
HTML5_CHANNELS = [
    # Ejemplo: {"name": "Canal HTML5", "url": "http://..."}
]

# ---------------------------------------------------------------
# Funciones de listado y reproducción
# ---------------------------------------------------------------

def list_categories():
    for category in CATEGORIES:
        list_item = xbmcgui.ListItem(label=category["name"])
        list_item.setArt({"icon": category["icon"]})
        url = build_url({"action": "list_channels", "category": category["name"]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def list_channels(category):
    selected_category = next((cat for cat in CATEGORIES if cat["name"] == category), None)
    if not selected_category:
        xbmcgui.Dialog().notification("Error", "Categoría no encontrada", xbmcgui.NOTIFICATION_ERROR)
        return
    if category == "AGENDA":
        list_agenda_events()
        return
    for channel in ACESTREAM_CHANNELS:
        if channel["name"].upper().startswith(category.upper()):
            list_item = xbmcgui.ListItem(label=channel["name"])
            list_item.setArt({"icon": channel["icon"]})  # Usa el ícono correspondiente
            url = build_url({"action": "play_acestream", "url": channel["url"]})
            list_item.setInfo("video", {"title": channel["name"]})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

# ---------------------------------------------------------------
# Función para procesar el archivo M3U y extraer canales (para AGENDA)
# ---------------------------------------------------------------

ICONOS_CANALES = {
    "F1": os.path.join(RESOURCES_PATH, "f1.png"),
    "M+": os.path.join(RESOURCES_PATH, "champions.png"),
    # Agrega más canales e íconos aquí
}

def obtener_canales_desde_m3u():
    url = "https://actualsebastian.vercel.app/kodi.txt"
    try:
        with urllib.request.urlopen(url) as response:
            content = response.read().decode("utf-8")
        lines = content.splitlines()
        # Remover la cabecera si existe
        if lines and lines[0].startswith("#EXTM3U"):
            lines = lines[1:]
        canales = []
        i = 0
        while i < len(lines):
            line = lines[i].strip()
            if line.startswith("#EXTINF"):
                parts = line.split(",", 1)
                channel_name = parts[1].strip() if len(parts) == 2 else "Sin nombre"
                if i + 1 < len(lines):
                    url_line = lines[i + 1].strip()
                else:
                    url_line = ""
                
                # Asignar un ícono al canal
                icon = ICONOS_CANALES.get(channel_name, os.path.join(RESOURCES_PATH, "default_icon.png"))
                
                canales.append({
                    "name": channel_name,
                    "url": url_line,
                    "icon": icon
                })
                i += 2
            else:
                i += 1
        xbmc.log("Se han obtenido %d canales del M3U" % len(canales), level=xbmc.LOGDEBUG)
        return canales
    except Exception as e:
        xbmcgui.Dialog().notification("Error", "Error al obtener canales: " + str(e), xbmcgui.NOTIFICATION_ERROR)
        return []

def list_agenda_events():
    canales = obtener_canales_desde_m3u()
    if not canales:
        xbmcgui.Dialog().notification("Agenda", "No hay canales disponibles", xbmcgui.NOTIFICATION_INFO)
        return
    for canal in canales:
        list_item = xbmcgui.ListItem(label=canal["name"])
        list_item.setArt({"icon": canal["icon"]})  # Establece el ícono para cada canal
        url = build_url({"action": "play_acestream", "url": canal["url"]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def mostrar_enlaces_evento(enlaces):
    # Si en algún caso deseas mostrar múltiples enlaces para un evento (formato JSON)
    enlaces = json.loads(enlaces)
    for enlace in enlaces:
        list_item = xbmcgui.ListItem(label=enlace["name"])
        url = build_url({"action": "play_acestream", "url": enlace["url"]})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def play_html5(url):
    try:
        xbmc.Player().play(url)
    except Exception as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)

def play_acestream(url):
    try:
        # Si la URL comienza con "acestream://", la procesamos; de lo contrario, asumimos que ya viene lista para reproducir
        if url.startswith("acestream://"):
            acestream_id = url.replace("acestream://", "")
            horus_url = f"plugin://script.module.horus/?action=play&id={acestream_id}"
        else:
            horus_url = url
        xbmc.Player().play(horus_url)
    except Exception as e:
        xbmcgui.Dialog().notification("Error", "Error al reproducir: " + str(e), xbmcgui.NOTIFICATION_ERROR)

# ---------------------------------------------------------------
# Bloque principal: determinar la acción a ejecutar
# ---------------------------------------------------------------

if __name__ == '__main__':
    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get("action")
    if action == "list_channels":
        category = args.get("category")
        if category == "AGENDA":
            list_agenda_events()
        else:
            list_channels(category)
    elif action == "mostrar_enlaces_evento":
        mostrar_enlaces_evento(args["enlaces"])
    elif action == "play_html5":
        play_html5(args["url"])
    elif action == "play_acestream":
        play_acestream(args["url"])
    else:
        list_categories()
